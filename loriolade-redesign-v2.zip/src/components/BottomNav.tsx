"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { HomeIcon, CalendarIcon, RunIcon, UserIcon, ShopIcon } from "@/components/icons";

const TABS = [
  { href: "/", label: "Accueil", icon: HomeIcon },
  { href: "/evenements?view=calendar", match: "/evenements", label: "Calendrier", icon: CalendarIcon },
  { href: "/evenements?type=seance", match: "/evenements", label: "Séances", icon: RunIcon },
  { href: "/membres", label: "Adhérents", icon: UserIcon },
  { href: "/boutique", label: "Boutique", icon: ShopIcon },
];

export function BottomNav() {
  const pathname = usePathname();

  return (
    <nav className="safe-bottom fixed inset-x-0 bottom-0 z-40 border-t border-zinc-200 bg-white/95 backdrop-blur dark:border-zinc-800 dark:bg-zinc-950/95">
      <div className="mx-auto flex max-w-4xl items-center justify-around px-2 py-2">
        {TABS.map((tab) => {
          const target = tab.match ?? tab.href;
          const isActive = target === "/" ? pathname === "/" : pathname.startsWith(target);
          const Icon = tab.icon;

          return (
            <Link
              key={tab.label}
              href={tab.href}
              className={`flex flex-col items-center gap-0.5 rounded-lg px-3 py-1 ${
                isActive ? "text-brand-orange" : "text-zinc-400 dark:text-zinc-500"
              }`}
            >
              <Icon className="h-6 w-6" />
              <span className="text-[10px] font-medium">{tab.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
