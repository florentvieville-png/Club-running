import { speedToPace, targetSpeedKmh, formatMinutes, formatSeconds } from "@/lib/pace";
import type { ClubEvent } from "@/lib/types/database";

function PaceTag({ vmaPct, myVma }: { vmaPct: number | null; myVma: number | null }) {
  if (vmaPct == null) return null;
  const speed = myVma ? targetSpeedKmh(myVma, vmaPct) : null;

  return (
    <span className="ml-1.5 whitespace-nowrap text-xs text-zinc-400">
      ({vmaPct}% VMA{speed ? ` · ${speedToPace(speed)}` : ""})
    </span>
  );
}

function BulletItem({
  text,
  vmaPct,
  myVma,
}: {
  text: string;
  vmaPct?: number | null;
  myVma: number | null;
}) {
  if (!text) return null;
  return (
    <li className="flex items-start gap-2 text-sm text-zinc-700 dark:text-zinc-300">
      <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-orange" />
      <span>
        {text}
        <PaceTag vmaPct={vmaPct ?? null} myVma={myVma} />
      </span>
    </li>
  );
}

export function SeancePlanCard({ event, myVma }: { event: ClubEvent; myVma: number | null }) {
  const hasPlan =
    event.warmup_minutes != null ||
    event.reps_count != null ||
    event.series_count != null ||
    event.cooldown_minutes != null;

  if (!hasPlan) return null;

  const repDetail =
    event.rep_unit === "distance" && event.rep_distance_m
      ? `${event.rep_distance_m} m`
      : event.rep_time_seconds
        ? formatSeconds(event.rep_time_seconds)
        : "";

  const repsLine = [
    event.series_count ? `${event.series_count} série${event.series_count > 1 ? "s" : ""}` : null,
    event.reps_count ? `${event.reps_count} x ${repDetail}` : null,
    event.rep_elevation_m ? `${event.rep_elevation_m} m D+` : null,
  ]
    .filter(Boolean)
    .join(" · ");

  const restLine = [
    event.rest_between_reps_seconds ? `${event.rest_between_reps_seconds}s entre reps` : null,
    event.rest_between_series_minutes
      ? `${formatMinutes(event.rest_between_series_minutes)} entre séries`
      : null,
  ]
    .filter(Boolean)
    .join(" · ");

  const cooldownLine = event.cooldown_minutes
    ? `Retour au calme ${formatMinutes(event.cooldown_minutes)}`
    : "";

  return (
    <section className="flex flex-col gap-4">
      <h2 className="text-sm font-semibold uppercase tracking-wide text-zinc-500">
        Plan de la séance {event.seance_type && `— ${event.seance_type}`}
      </h2>

      {!myVma && (
        <p className="rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-800 dark:bg-amber-950 dark:text-amber-200">
          Renseignez votre VMA dans votre profil (page Membres) pour voir vos allures cibles
          personnalisées.
        </p>
      )}

      {event.warmup_minutes != null && (
        <div className="flex flex-col gap-1.5">
          <h3 className="font-bold text-brand-blue-dark dark:text-blue-300">Échauffement</h3>
          <ul className="flex flex-col gap-1">
            <BulletItem
              text={formatMinutes(event.warmup_minutes)}
              vmaPct={event.warmup_vma_pct}
              myVma={myVma}
            />
          </ul>
        </div>
      )}

      {(repsLine || restLine || cooldownLine) && (
        <div className="flex flex-col gap-1.5">
          <h3 className="font-bold text-brand-blue-dark dark:text-blue-300">Corps de séance</h3>
          <ul className="flex flex-col gap-1">
            <BulletItem text={repsLine} vmaPct={event.rep_vma_pct} myVma={myVma} />
            <BulletItem text={restLine} vmaPct={event.rest_vma_pct} myVma={myVma} />
            <BulletItem text={cooldownLine} vmaPct={event.cooldown_vma_pct} myVma={myVma} />
          </ul>
        </div>
      )}
    </section>
  );
}
